import { Component } from '@angular/core';

@Component({
    template: `
    <h1>Admin</h1>
    <span>dsdadas</span>
    <admin-grid>Loading...</admin-grid>`
})

export class AdminComponent {}